# HCMP Bug Fix Package
# Date: 2026-03-23
# Copy đè các file này vào đúng vị trí trong project rồi git push

## DANH SÁCH FILE VÀ VỊ TRÍ COPY:

### BACKEND (packages/api/src/modules/...)

1. auth.controller.ts
   → Copy đè: packages/api/src/modules/auth/auth.controller.ts
   → Fix: Thêm endpoint register, change-password, reset-password

2. auth.service.ts
   → Copy đè: packages/api/src/modules/auth/auth.service.ts
   → Fix: Logic tạo user, đổi pass, reset pass

3. buildings.controller.ts
   → Copy đè: packages/api/src/modules/buildings/buildings.controller.ts
   → Fix: Thêm cập nhật giá phòng (basePrice) trong endpoint update unit

4. ai-agent.service.ts
   → Copy đè: packages/api/src/modules/ai-agent/ai-agent.service.ts
   → Fix: Thêm tool get_daily_report - AI Lena trả lời thống kê doanh thu/booking/phòng

### FRONTEND (apps/web/src/app/...)

5. bookings-page.tsx
   → Copy đè: apps/web/src/app/dashboard/bookings/page.tsx
   → Fix: Nút Xác nhận / Hủy / Check-in / Check-out booking

6. settings-page.tsx
   → Copy đè: apps/web/src/app/dashboard/settings/page.tsx
   → Fix: 5 tab - Tòa nhà, Người dùng (tạo/xóa), Mật khẩu, Giá phòng, AI

7. tablet-page.tsx
   → Copy đè: apps/web/src/app/tablet/page.tsx
   → Fix: Load guest thật từ API thay vì hardcode "Minh Nguyễn"
   → Tablet hỗ trợ tham số ?room=2.2 để hiển thị khách đúng phòng

## CÁCH ÁP DỤNG:

### Cách 1: Trên máy local (nhanh nhất)
```powershell
cd C:\Users\WELCOME\HCMD

# Backend
copy DOWNLOAD_FOLDER\auth.controller.ts packages\api\src\modules\auth\auth.controller.ts
copy DOWNLOAD_FOLDER\auth.service.ts packages\api\src\modules\auth\auth.service.ts
copy DOWNLOAD_FOLDER\buildings.controller.ts packages\api\src\modules\buildings\buildings.controller.ts
copy DOWNLOAD_FOLDER\ai-agent.service.ts packages\api\src\modules\ai-agent\ai-agent.service.ts

# Frontend
copy DOWNLOAD_FOLDER\bookings-page.tsx apps\web\src\app\dashboard\bookings\page.tsx
copy DOWNLOAD_FOLDER\settings-page.tsx apps\web\src\app\dashboard\settings\page.tsx
copy DOWNLOAD_FOLDER\tablet-page.tsx apps\web\src\app\tablet\page.tsx

# Push
git add .
git commit -m "fix: full business logic - admin actions, AI reports, tablet dynamic guest"
git push
```

### Cách 2: Trên GitHub (nếu không có máy)
Mở từng file trên GitHub → Edit → xóa hết → paste nội dung file mới → Commit
