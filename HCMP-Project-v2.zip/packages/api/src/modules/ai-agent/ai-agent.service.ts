import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../common/prisma.service';

@Injectable()
export class AiAgentService {
  constructor(private prisma: PrismaService) {}

  async chat(input: {
    message: string;
    bookingId?: string;
    guestId?: string;
    deviceType?: string;
    lang?: string;
  }) {
    // TODO: Integrate Claude API with tool calling
    // For now, return a placeholder response
    return {
      response: `[AI Agent placeholder] Received: "${input.message}". Claude API integration coming in Phase 2.`,
      intent: 'unknown',
      deviceType: input.deviceType || 'webchat',
      lang: input.lang || 'vi',
      timestamp: new Date().toISOString(),
    };
  }

  async getConversations(bookingId?: string, guestId?: string) {
    return this.prisma.conversation.findMany({
      where: {
        ...(bookingId && { bookingId }),
        ...(guestId && { guestId }),
      },
      orderBy: { lastMsgAt: 'desc' },
      take: 20,
    });
  }
}
