import { Controller, Get, Param, Query } from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import { GuestsService } from './guests.service';

@ApiTags('Guests')
@Controller('guests')
export class GuestsController {
  constructor(private guestsService: GuestsService) {}

  @Get()
  @ApiOperation({ summary: 'List guests' })
  async findAll(@Query('limit') limit?: string) {
    return this.guestsService.findAll(limit ? parseInt(limit) : 50);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get guest detail' })
  async findOne(@Param('id') id: string) {
    return this.guestsService.findOne(id);
  }
}
