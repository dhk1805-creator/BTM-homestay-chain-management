'use client';

import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import {
  Building2, CalendarDays, BedDouble, Star,
  TrendingUp, AlertCircle, Users, ArrowUpRight, ArrowDownRight,
} from 'lucide-react';

interface Stats {
  totalBuildings: number;
  totalUnits: number;
  totalBookings: number;
  occupancyRate: number;
  revenueThisMonth: number;
  todayCheckins: number;
  todayCheckouts: number;
  openIncidents: number;
  avgRating: number;
  totalReviews: number;
}

interface RecentBooking {
  id: string;
  status: string;
  checkInDate: string;
  checkOutDate: string;
  numGuests: number;
  totalAmount: string;
  guest: { firstName: string; lastName: string; email: string };
  unit: { name: string; building: { name: string } };
  channel: { name: string } | null;
}

interface OpenIncident {
  id: string;
  type: string;
  status: string;
  priority: string;
  description: string;
  createdAt: string;
  unit: { name: string; building: { name: string } };
}

function formatVND(amount: number) {
  if (amount >= 1_000_000) return `₫ ${Math.round(amount / 1_000_000)}M`;
  if (amount >= 1_000) return `₫ ${Math.round(amount / 1_000)}K`;
  return `₫ ${amount}`;
}

function formatDate(d: string) {
  return new Date(d).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' });
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    CONFIRMED: 'bg-blue-50 text-blue-700',
    CHECKED_IN: 'bg-green-50 text-green-700',
    CHECKED_OUT: 'bg-gray-100 text-gray-600',
    PENDING: 'bg-yellow-50 text-yellow-700',
    CANCELLED: 'bg-red-50 text-red-700',
    OPEN: 'bg-red-50 text-red-700',
    IN_PROGRESS: 'bg-yellow-50 text-yellow-700',
  };
  const label: Record<string, string> = {
    CONFIRMED: 'Xác nhận',
    CHECKED_IN: 'Đã check-in',
    CHECKED_OUT: 'Đã check-out',
    PENDING: 'Chờ',
    CANCELLED: 'Đã hủy',
    OPEN: 'Mở',
    IN_PROGRESS: 'Đang xử lý',
  };
  return (
    <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${map[status] || 'bg-gray-100 text-gray-600'}`}>
      {label[status] || status}
    </span>
  );
}

function PriorityBadge({ priority }: { priority: string }) {
  const map: Record<string, string> = {
    high: 'bg-red-50 text-red-700',
    medium: 'bg-yellow-50 text-yellow-700',
    low: 'bg-green-50 text-green-700',
  };
  return (
    <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${map[priority] || 'bg-gray-100 text-gray-600'}`}>
      {priority}
    </span>
  );
}

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [bookings, setBookings] = useState<RecentBooking[]>([]);
  const [incidents, setIncidents] = useState<OpenIncident[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function load() {
      try {
        const [s, b, i] = await Promise.all([
          apiFetch<Stats>('/dashboard/stats'),
          apiFetch<RecentBooking[]>('/dashboard/bookings/recent?limit=5'),
          apiFetch<OpenIncident[]>('/dashboard/incidents/open'),
        ]);
        setStats(s);
        setBookings(b);
        setIncidents(i);
      } catch (err: any) {
        setError(err.message || 'Không thể tải dữ liệu');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-sm text-gray-500">Đang tải dữ liệu...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-center">
          <AlertCircle className="w-8 h-8 text-red-400 mx-auto mb-2" />
          <p className="text-red-700 font-medium mb-1">Lỗi kết nối API</p>
          <p className="text-sm text-red-600 mb-3">{error}</p>
          <p className="text-xs text-red-500">Kiểm tra NestJS API đang chạy tại localhost:3001</p>
        </div>
      </div>
    );
  }

  if (!stats) return null;

  const metricCards = [
    { label: 'Doanh thu tháng', value: formatVND(stats.revenueThisMonth), icon: TrendingUp, color: 'text-brand-500', bg: 'bg-blue-50' },
    { label: 'Tỉ lệ lấp đầy', value: `${stats.occupancyRate}%`, icon: BedDouble, color: 'text-success-500', bg: 'bg-green-50' },
    { label: 'Booking hôm nay', value: `${stats.todayCheckins + stats.todayCheckouts}`, sub: `${stats.todayCheckins} in · ${stats.todayCheckouts} out`, icon: CalendarDays, color: 'text-brand-500', bg: 'bg-blue-50' },
    { label: 'Rating TB', value: stats.avgRating.toFixed(2), sub: `${stats.totalReviews} reviews`, icon: Star, color: 'text-yellow-500', bg: 'bg-yellow-50' },
  ];

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-lg font-semibold text-gray-900">Tổng quan chuỗi</h1>
          <p className="text-sm text-gray-500">
            {stats.totalBuildings} tòa nhà · {stats.totalUnits} căn hộ hoạt động
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-gray-500 bg-gray-100 px-3 py-1.5 rounded-lg">
            {new Date().toLocaleDateString('vi-VN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </span>
          {stats.openIncidents > 0 && (
            <a href="/dashboard/incidents"
              className="flex items-center gap-1.5 bg-red-50 text-red-700 text-xs font-medium px-3 py-1.5 rounded-lg hover:bg-red-100 transition">
              <AlertCircle size={13} />
              {stats.openIncidents} incident
            </a>
          )}
        </div>
      </div>

      {/* Metric cards */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {metricCards.map((m) => (
          <div key={m.label} className="bg-white rounded-xl border border-gray-200 p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className={`w-7 h-7 rounded-lg ${m.bg} flex items-center justify-center`}>
                <m.icon size={14} className={m.color} />
              </div>
              <span className="text-xs text-gray-500">{m.label}</span>
            </div>
            <p className="text-2xl font-semibold text-gray-900">{m.value}</p>
            {m.sub && <p className="text-xs text-gray-500 mt-1">{m.sub}</p>}
          </div>
        ))}
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-2 gap-4">
        {/* Recent bookings */}
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-gray-900">Booking gần nhất</h3>
            <a href="/dashboard/bookings" className="text-xs text-brand-500 hover:underline">Xem tất cả</a>
          </div>
          {bookings.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-6">Chưa có booking nào</p>
          ) : (
            <div className="space-y-3">
              {bookings.map((b) => (
                <div key={b.id} className="flex items-center gap-3 py-2 border-b border-gray-50 last:border-0">
                  <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center text-xs font-medium text-brand-500">
                    {b.guest.firstName.charAt(0)}{b.guest.lastName.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {b.guest.firstName} {b.guest.lastName}
                    </p>
                    <p className="text-xs text-gray-500">
                      {b.unit.name} · {b.unit.building.name} · {formatDate(b.checkInDate)}→{formatDate(b.checkOutDate)}
                    </p>
                  </div>
                  <StatusBadge status={b.status} />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Open incidents */}
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-gray-900">Incidents mở</h3>
            <a href="/dashboard/incidents" className="text-xs text-brand-500 hover:underline">Quản lý</a>
          </div>
          {incidents.length === 0 ? (
            <div className="text-center py-6">
              <div className="w-10 h-10 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-2">
                <AlertCircle size={18} className="text-green-500" />
              </div>
              <p className="text-sm text-gray-500">Không có incident mở</p>
            </div>
          ) : (
            <div className="space-y-3">
              {incidents.map((inc) => (
                <div key={inc.id} className="flex items-start gap-3 py-2 border-b border-gray-50 last:border-0">
                  <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${
                    inc.priority === 'high' ? 'bg-red-500' : inc.priority === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-900">{inc.description}</p>
                    <p className="text-xs text-gray-500">{inc.unit.name} · {inc.unit.building.name}</p>
                  </div>
                  <PriorityBadge priority={inc.priority} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
