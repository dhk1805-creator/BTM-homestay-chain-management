'use client';

import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { CalendarDays } from 'lucide-react';

interface BookingItem {
  id: string;
  status: string;
  checkInDate: string;
  checkOutDate: string;
  numGuests: number;
  totalAmount: string;
  currency: string;
  guest: { firstName: string; lastName: string; email: string; phone: string | null };
  unit: { name: string; building: { name: string } };
  channel: { name: string } | null;
}

const statusColors: Record<string, string> = {
  PENDING: 'bg-yellow-50 text-yellow-700',
  CONFIRMED: 'bg-blue-50 text-blue-700',
  CHECKED_IN: 'bg-green-50 text-green-700',
  CHECKED_OUT: 'bg-gray-100 text-gray-600',
  CANCELLED: 'bg-red-50 text-red-700',
};

const statusLabels: Record<string, string> = {
  PENDING: 'Chờ', CONFIRMED: 'Xác nhận', CHECKED_IN: 'Đã check-in',
  CHECKED_OUT: 'Đã check-out', CANCELLED: 'Đã hủy',
};

export default function BookingsPage() {
  const [bookings, setBookings] = useState<BookingItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    const params = filter ? `?status=${filter}` : '';
    apiFetch<BookingItem[]>(`/bookings${params}`)
      .then(setBookings)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [filter]);

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-lg font-semibold text-gray-900">Bookings</h1>
          <p className="text-sm text-gray-500">{bookings.length} đơn đặt phòng</p>
        </div>
        <div className="flex gap-2">
          {['', 'CONFIRMED', 'CHECKED_IN', 'CHECKED_OUT'].map((s) => (
            <button key={s}
              onClick={() => { setLoading(true); setFilter(s); }}
              className={`text-xs px-3 py-1.5 rounded-lg transition ${
                filter === s ? 'bg-brand-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}>
              {s ? statusLabels[s] : 'Tất cả'}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : bookings.length === 0 ? (
        <div className="text-center py-12">
          <CalendarDays size={32} className="text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">Chưa có booking nào</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50">
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500">Khách</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500">Phòng</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500">Check-in</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500">Check-out</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500">Kênh</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500">Trạng thái</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-gray-500">Số tiền</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((b) => (
                <tr key={b.id} className="border-b border-gray-50 hover:bg-gray-50 transition cursor-pointer">
                  <td className="px-4 py-3">
                    <p className="font-medium text-gray-900">{b.guest.firstName} {b.guest.lastName}</p>
                    <p className="text-xs text-gray-500">{b.guest.email}</p>
                  </td>
                  <td className="px-4 py-3">
                    <p className="text-gray-900">{b.unit.name}</p>
                    <p className="text-xs text-gray-500">{b.unit.building.name}</p>
                  </td>
                  <td className="px-4 py-3 text-gray-700">
                    {new Date(b.checkInDate).toLocaleDateString('vi-VN')}
                  </td>
                  <td className="px-4 py-3 text-gray-700">
                    {new Date(b.checkOutDate).toLocaleDateString('vi-VN')}
                  </td>
                  <td className="px-4 py-3 text-gray-600">{b.channel?.name || '—'}</td>
                  <td className="px-4 py-3">
                    <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${statusColors[b.status] || ''}`}>
                      {statusLabels[b.status] || b.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-medium text-gray-900">
                    {Number(b.totalAmount).toLocaleString('vi-VN')} ₫
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
