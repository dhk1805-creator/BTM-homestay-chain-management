'use client';

import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { getUser, logout } from '@/lib/api';
import {
  LayoutDashboard, Building2, CalendarDays, Users,
  Bot, AlertCircle, FileBarChart, Settings, LogOut,
} from 'lucide-react';

const navItems = [
  { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { label: 'Buildings', href: '/dashboard/buildings', icon: Building2 },
  { label: 'Bookings', href: '/dashboard/bookings', icon: CalendarDays },
  { label: 'Khách', href: '/dashboard/guests', icon: Users },
  { label: 'AI Agent', href: '/dashboard/ai-agent', icon: Bot },
  { label: 'Incidents', href: '/dashboard/incidents', icon: AlertCircle },
  { label: 'Báo cáo', href: '/dashboard/reports', icon: FileBarChart },
  { label: 'Cài đặt', href: '/dashboard/settings', icon: Settings },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const u = getUser();
    if (!u) {
      router.push('/login');
      return;
    }
    setUser(u);
  }, [router]);

  if (!user) return null;

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-56 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-4 flex items-center gap-2.5">
          <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center">
            <svg width="16" height="16" viewBox="0 0 14 14" fill="none">
              <rect x="1" y="1" width="5" height="5" rx="1" fill="#85B7EB" />
              <rect x="8" y="1" width="5" height="5" rx="1" fill="#85B7EB" />
              <rect x="1" y="8" width="5" height="5" rx="1" fill="#5DCAA5" />
              <rect x="8" y="8" width="5" height="5" rx="1" fill="#5DCAA5" />
            </svg>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-900">HomeStay Chain</p>
            <p className="text-[10px] text-gray-500">Admin Portal</p>
          </div>
        </div>

        <nav className="flex-1 px-3 py-2 space-y-0.5">
          {navItems.map((item) => {
            const isActive = pathname === item.href || (item.href !== '/dashboard' && pathname.startsWith(item.href));
            return (
              <a
                key={item.href}
                href={item.href}
                className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition
                  ${isActive ? 'bg-blue-50 text-brand-500 font-medium' : 'text-gray-600 hover:bg-gray-50'}`}
              >
                <item.icon size={16} className={isActive ? 'text-brand-500' : 'text-gray-400'} />
                {item.label}
              </a>
            );
          })}
        </nav>

        <div className="p-3 border-t border-gray-200">
          <div className="flex items-center gap-2.5 px-3 py-2">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-xs font-medium text-brand-500">
              {user.name?.charAt(0) || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-gray-900 truncate">{user.name}</p>
              <p className="text-[10px] text-gray-500">{user.role}</p>
            </div>
            <button onClick={logout} className="text-gray-400 hover:text-red-500">
              <LogOut size={14} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  );
}
