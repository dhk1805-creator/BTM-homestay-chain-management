'use client';

import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { Building2, MapPin, BedDouble } from 'lucide-react';

interface BuildingItem {
  id: string;
  name: string;
  address: string;
  city: string;
  active: boolean;
  _count: { units: number };
  units: { id: string; status: string }[];
}

export default function BuildingsPage() {
  const [buildings, setBuildings] = useState<BuildingItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch<BuildingItem[]>('/dashboard/buildings')
      .then(setBuildings)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-lg font-semibold text-gray-900">Buildings</h1>
          <p className="text-sm text-gray-500">{buildings.length} tòa nhà trong chuỗi</p>
        </div>
        <button className="bg-brand-500 text-white text-sm px-4 py-2 rounded-lg hover:bg-brand-600 transition">
          + Thêm tòa nhà
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {buildings.map((b) => {
          const occupied = b.units.filter((u) => u.status === 'OCCUPIED').length;
          const total = b._count.units;
          const rate = total > 0 ? Math.round((occupied / total) * 100) : 0;

          return (
            <a key={b.id} href={`/dashboard/buildings/${b.id}`}
              className="bg-white rounded-xl border border-gray-200 p-5 hover:border-brand-500 hover:shadow-sm transition">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center">
                  <Building2 size={18} className="text-brand-500" />
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-semibold text-gray-900">{b.name}</h3>
                  <p className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                    <MapPin size={11} /> {b.city}
                  </p>
                </div>
              </div>
              <p className="text-xs text-gray-500 mb-3">{b.address}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs text-gray-600">
                  <BedDouble size={13} className="text-gray-400" />
                  {total} phòng
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${rate >= 80 ? 'bg-green-500' : rate >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`}
                      style={{ width: `${rate}%` }}
                    />
                  </div>
                  <span className="text-xs font-medium text-gray-700">{rate}%</span>
                </div>
              </div>
            </a>
          );
        })}

        {buildings.length === 0 && (
          <div className="col-span-full text-center py-12">
            <Building2 size={32} className="text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">Chưa có tòa nhà nào. Chạy seed data trước.</p>
          </div>
        )}
      </div>
    </div>
  );
}
